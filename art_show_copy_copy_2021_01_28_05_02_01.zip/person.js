// Daniel Shiffman
// https://www.kadenze.com/courses/the-nature-of-code
// http://natureofcode.com/
// Session 2: Array of Particles, multiple forces

function Person() {
  this.pos = createVector(150, height - 10);
  this.vel = createVector(0.25, 0);
  this.acc = createVector(0, 0);
  this.score = 0;


  this.applyForce = function(force) {
    var f = force.copy();
    f.div(10);
    this.acc.add(f);
  }

  this.update = function() {
    this.vel.add(this.acc);
    this.pos.add(this.vel);
    this.acc.set(0, 0);
  }

  this.display = function() {


    fill(2, 10, 10);
    noStroke(255);
    //image();
    rect(this.pos.x, this.pos.y - 20, 20, 20,5);

   

  }

  this.hits = function(obs) {


    if ((obs.pos.x >= this.pos.x && obs.pos.x <= (this.pos.x + 20)) &&
      (obs.pos.y >= this.pos.y - 20 && obs.pos.y <= (this.pos.y + 20))) {
      this.score = this.score + obs.val;
      obs.pos.y = 10;

    }
    // collideRectRect(this.pos.x,this.pos.y,50,50, obs.pos.x,obs.pos.y,10,10);
  }



  this.edges = function() {
    if (this.pos.y >= 340) {
      this.vel.y *= -0;
      this.pos.y = 340;
    } else if (this.pos.y < 20) {
      this.vel.y *= 0;
      this.pos.y = 20;
    }
  }
}