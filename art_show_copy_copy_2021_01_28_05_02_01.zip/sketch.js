let rainDrop;
let wave;
function preload (){
  rainDrop = loadImage('RainDrop2.png')
  wave = loadImage('wavet.png')
}

var man;
var bad = [];
var bad2 = [];
var sceneNum = 0;
var sceneX = 1;
//finish up hit function https://www.youtube.com/watch?v=l0HoJHc-63Q&t=1027s
function setup() {
  createCanvas(640, 360);
  man = new Person();
  for (let i = 0; i < 100; i++) {
    bad[i] = new obstacle();
  }
  for (let l = 0; l < 100;   l++) {
    bad2[l] = new obstacle2();
}

}

function keyPressed() {
  if (key == ' ') {
    let force = createVector(0, -5);
    man.applyForce(force);
  } else if (key == 'd') {
    sceneNum++;

  }

  if (sceneNum > 2) {
    sceneNum = 0;
  }
}

function draw() {
  
 
  if (sceneNum === 0) {
    scene0();

  } else if (sceneNum === 1) {
    scene1();
  } else if (sceneNum === 2) {
    scene2();
  } else if (sceneNum === 3) {
    scene3();
  } 
  if (man.score >= 10) {
      sceneNum = 2;
    }
  if (man.score <= -1) {
      sceneNum = 3;
    }
   if (man.pos.x >= 400){
      sceneNum = 2;    
  }

}

function scene1() {
  
  background(15, 26, 235);
  
  image(wave,0,180,300,200)
  fill(0, 128, 0)
  rect(0, 340, 640, 20);
  translate(-man.pos.x + 200, 0);
  let gravity = createVector(0, 0.2)
  man.applyForce(gravity);
  man.update();
  man.display();
  man.edges();
  //Silly hard code or obstacle


  for (l = 0; l < 30; l++) {
    if (man.hits(bad2[l])) {
      console.log("Game Over!");
      console.log(bad2[l].pos.x);
    }
    //console.log(bad2[l].pos.x);

    bad2[l].show();
    bad2[l].update();
  }

}
function scene0() {
  background("blue");
  textSize(70);
  text("Escape The Flood", 20, 100);
  textSize(30);
  text("press d to continue", 200, 200);
  
}

function scene2() {
  background("purple");
  textSize(50);
  text("You Win",200,200)
  }

function scene3() {
  background("purple");
  textSize(50);
  text("You Lose",200,200)

}

